import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Business } from '../types';
import { api } from '../services/api';

interface AuthContextType {
  user: User | null;
  business: Business | null;
  currentBusinessId: string;
  token: string | null;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => void;
  switchDemoRole: (role: 'OWNER' | 'EMPLOYEE' | 'CUSTOMER' | 'SUPER_ADMIN' | 'BIZ_2') => Promise<void>;
  setCurrentBusinessId: (id: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [business, setBusiness] = useState<Business | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('shopmate_token'));
  const [currentBusinessId, setCurrentBizId] = useState<string>(
    localStorage.getItem('shopmate_current_biz_id') || 'biz_kalakriti_001'
  );
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const setCurrentBusinessId = (id: string) => {
    setCurrentBizId(id);
    localStorage.setItem('shopmate_current_biz_id', id);
  };

  useEffect(() => {
    async function loadUser() {
      if (!token) {
        setIsLoading(false);
        return;
      }
      try {
        const data = await api.getMe();
        setUser(data.user);
        if (data.business) {
          setBusiness(data.business);
          setCurrentBusinessId(data.business.id);
        }
      } catch (err) {
        console.warn('Session expired, clearing token');
        setToken(null);
        localStorage.removeItem('shopmate_token');
      } finally {
        setIsLoading(false);
      }
    }
    loadUser();
  }, [token]);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await api.login(email, pass);
      setUser(res.user);
      setToken(res.token);
      localStorage.setItem('shopmate_token', res.token);
      if (res.user.business_id) {
        setCurrentBusinessId(res.user.business_id);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: any) => {
    setIsLoading(true);
    try {
      const res = await api.register(data);
      setUser(res.user);
      setToken(res.token);
      localStorage.setItem('shopmate_token', res.token);
      if (res.user.business_id) {
        setCurrentBusinessId(res.user.business_id);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setBusiness(null);
    setToken(null);
    localStorage.removeItem('shopmate_token');
  };

  const switchDemoRole = async (role: 'OWNER' | 'EMPLOYEE' | 'CUSTOMER' | 'SUPER_ADMIN' | 'BIZ_2') => {
    let email = 'owner@shopmate.com';
    let pass = 'admin123';

    if (role === 'EMPLOYEE') {
      email = 'priya@shopmate.com';
      pass = 'employee123';
    } else if (role === 'CUSTOMER') {
      email = 'ananya@example.com';
      pass = 'customer123';
    } else if (role === 'SUPER_ADMIN') {
      email = 'superadmin@shopmate.com';
      pass = 'super123';
    } else if (role === 'BIZ_2') {
      email = 'owner2@urbanvogue.com';
      pass = 'urban123';
    }

    await login(email, pass);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        business,
        currentBusinessId,
        token,
        isLoading,
        login,
        register,
        logout,
        switchDemoRole,
        setCurrentBusinessId,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
