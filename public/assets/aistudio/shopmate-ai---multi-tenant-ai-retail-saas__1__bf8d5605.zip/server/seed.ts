import { db } from './db.js';
import crypto from 'node:crypto';

export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export function seedDatabase() {
  // Check if data already exists
  const existingUsers = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (existingUsers && existingUsers.count > 0) {
    console.log('Database already seeded. Skipping initial seed.');
    return;
  }

  console.log('Seeding ShopMate AI database with realistic retail data...');

  const biz1Id = 'biz_kalakriti_001';
  const biz2Id = 'biz_urbanvogue_002';

  // 1. Businesses
  const insertBiz = db.prepare(`
    INSERT INTO businesses (id, name, slug, category, phone, email, address, currency, ai_greeting, is_active)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertBiz.run(
    biz1Id,
    'KalaKriti Ethnic & Modern Wear',
    'kalakriti',
    'Clothing & Ethnic Fashion',
    '+91 98765 43210',
    'contact@kalakriti.in',
    '108 Commercial Street, Bengaluru, Karnataka, 560001',
    '₹',
    'Namaste! Welcome to KalaKriti Ethnic & Modern Wear. I am your ShopMate AI shopping assistant. How can I help you find the perfect outfit today?',
    1
  );

  insertBiz.run(
    biz2Id,
    'UrbanVogue Fashion Store',
    'urbanvogue',
    'Contemporary Fashion',
    '+91 91234 56789',
    'hello@urbanvogue.com',
    '42 Linking Road, Bandra West, Mumbai, 400050',
    '₹',
    'Hello! Welcome to UrbanVogue. Looking for sleek everyday styles or formal wear? Ask me anything!',
    1
  );

  // 2. Users
  const insertUser = db.prepare(`
    INSERT INTO users (id, email, password_hash, name, role, business_id, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  // Super Admin
  insertUser.run(
    'usr_superadmin',
    'superadmin@shopmate.com',
    hashPassword('super123'),
    'Aarav Sharma (Platform Admin)',
    'SUPER_ADMIN',
    null,
    '+91 99999 00000'
  );

  // Business Owner 1
  insertUser.run(
    'usr_owner_1',
    'owner@shopmate.com',
    hashPassword('admin123'),
    'Rajesh Patel (Store Owner)',
    'BUSINESS_OWNER',
    biz1Id,
    '+91 98765 43210'
  );

  // Employee 1
  insertUser.run(
    'usr_emp_1',
    'priya@shopmate.com',
    hashPassword('employee123'),
    'Priya Nair (Sales Executive)',
    'EMPLOYEE',
    biz1Id,
    '+91 98765 43211'
  );

  // Customer 1
  insertUser.run(
    'usr_cust_1',
    'ananya@example.com',
    hashPassword('customer123'),
    'Ananya Sen',
    'CUSTOMER',
    biz1Id,
    '+91 98765 11111'
  );

  // Business Owner 2 (Separate tenant)
  insertUser.run(
    'usr_owner_2',
    'owner2@urbanvogue.com',
    hashPassword('urban123'),
    'Vikram Malhotra',
    'BUSINESS_OWNER',
    biz2Id,
    '+91 91234 56789'
  );

  // 3. Product Categories for KalaKriti
  const categories = [
    { id: 'cat_kurtis', name: 'Kurtis & Kurta Sets', slug: 'kurtis', desc: 'Handcrafted cotton, silk, and georgette designer kurtis', img: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_sarees', name: 'Sarees', slug: 'sarees', desc: 'Exquisite Banarasi, Kanjivaram, Chanderi, and Organza sarees', img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_dresses', name: 'Dresses & Gowns', slug: 'dresses', desc: 'Contemporary fusion maxi dresses and festive gowns', img: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_shirts', name: 'Men & Women Shirts', slug: 'shirts', desc: 'Premium linen, printed cotton, and formal office shirts', img: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_tshirts', name: 'T-Shirts & Polos', slug: 't-shirts', desc: 'Casual everyday tees, oversized graphics, and polo collar shirts', img: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_jeans', name: 'Jeans & Trousers', slug: 'jeans', desc: 'Stretch denim, wide leg palazzos, and formal trousers', img: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_footwear', name: 'Footwear & Juttis', slug: 'footwear', desc: 'Traditional Punjabi juttis, kolhapuris, and comfortable flats', img: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80' },
    { id: 'cat_jewellery', name: 'Jewellery & Accessories', slug: 'jewellery', desc: 'Kundan necklaces, jhumkas, chokers, and festive clutches', img: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80' },
  ];

  const insertCat = db.prepare(`
    INSERT INTO product_categories (id, business_id, name, slug, description, image_url)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  for (const c of categories) {
    insertCat.run(c.id, biz1Id, c.name, c.slug, c.desc, c.img);
  }

  // Categories for Biz 2
  insertCat.run('cat_uv_street', biz2Id, 'Streetwear & Denim', 'streetwear', 'Urban trends and relaxed fits', 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=600&auto=format&fit=crop&q=80');

  // 4. Seed Products (30+ realistic products)
  const productsData = [
    // Kurtis (1-5)
    {
      id: 'prd_01', cat: 'cat_kurtis', name: 'Anarkali Pure Cotton Kurti with Dupatta', sku: 'KK-KUR-001',
      brand: 'KalaKriti Heritage', regPrice: 1899, discPrice: 1399, colour: 'Red',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Flowy flare Anarkali kurti made from 100% breathable cambric cotton with intricate gold foil block prints and matching organza border dupatta.',
      images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'S', colour: 'Red', stock: 12, price: 1399 },
        { size: 'M', colour: 'Red', stock: 18, price: 1399 },
        { size: 'L', colour: 'Red', stock: 14, price: 1399 },
        { size: 'XL', colour: 'Red', stock: 8, price: 1399 },
      ]
    },
    {
      id: 'prd_02', cat: 'cat_kurtis', name: 'Straight Cut Indigo Block Print Kurti', sku: 'KK-KUR-002',
      brand: 'KalaKriti Heritage', regPrice: 1299, discPrice: 949, colour: 'Blue',
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      desc: 'Classic straight cut office-wear kurti crafted in natural vegetable indigo dyes with wooden button detailing and side slit.',
      images: ['https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&auto=format&fit=crop&q=80'],
      minStock: 5,
      variants: [
        { size: 'S', colour: 'Blue', stock: 15, price: 949 },
        { size: 'M', colour: 'Blue', stock: 22, price: 949 },
        { size: 'L', colour: 'Blue', stock: 19, price: 949 },
        { size: 'XL', colour: 'Blue', stock: 10, price: 949 },
        { size: 'XXL', colour: 'Blue', stock: 6, price: 949 },
      ]
    },
    {
      id: 'prd_03', cat: 'cat_kurtis', name: 'Embroidered Chanderi Silk Festive Kurti', sku: 'KK-KUR-003',
      brand: 'KalaKriti Heritage', regPrice: 2499, discPrice: 1899, colour: 'Emerald Green',
      sizes: ['M', 'L', 'XL'],
      desc: 'Royal Chanderi silk kurti featuring Zari neck embroidery, quarter sleeves with scalloped borders. Perfect for festive gatherings.',
      images: ['https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'M', colour: 'Emerald Green', stock: 8, price: 1899 },
        { size: 'L', colour: 'Emerald Green', stock: 10, price: 1899 },
        { size: 'XL', colour: 'Emerald Green', stock: 5, price: 1899 },
      ]
    },
    {
      id: 'prd_04', cat: 'cat_kurtis', name: 'Pastel Floral Chikankari Georgette Kurti', sku: 'KK-KUR-004',
      brand: 'Lucknowi Grace', regPrice: 1799, discPrice: 1299, colour: 'Peach Pink',
      sizes: ['S', 'M', 'L'],
      desc: 'Delicate hand-embroidered Bakhiya and Phanda stitch Lucknowi Chikankari work on soft pastel georgette with matching inner slip.',
      images: ['https://images.unsplash.com/photo-1609357605129-26f69add5d6e?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'S', colour: 'Peach Pink', stock: 9, price: 1299 },
        { size: 'M', colour: 'Peach Pink', stock: 14, price: 1299 },
        { size: 'L', colour: 'Peach Pink', stock: 11, price: 1299 },
      ]
    },
    {
      id: 'prd_05', cat: 'cat_kurtis', name: 'Yellow Haldi Tiered Flared Festive Kurti', sku: 'KK-KUR-005',
      brand: 'KalaKriti Heritage', regPrice: 1599, discPrice: 1199, colour: 'Mustard Yellow',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Bright mustard yellow 3-tier flared kurti adorned with Gota Patti trims on yoke. Ideal for Haldi and Sangeet celebrations.',
      images: ['https://images.unsplash.com/photo-1583391733975-0810ef38c23f?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'S', colour: 'Mustard Yellow', stock: 7, price: 1199 },
        { size: 'M', colour: 'Mustard Yellow', stock: 12, price: 1199 },
        { size: 'L', colour: 'Mustard Yellow', stock: 8, price: 1199 },
        { size: 'XL', colour: 'Mustard Yellow', stock: 4, price: 1199 },
      ]
    },

    // Sarees (6-10)
    {
      id: 'prd_06', cat: 'cat_sarees', name: 'Banarasi Katan Silk Woven Saree in Crimson Red', sku: 'KK-SAR-001',
      brand: 'Varanasi Weaves', regPrice: 4999, discPrice: 3499, colour: 'Crimson Red',
      sizes: ['Free Size (5.5m + 0.8m Blouse)'],
      desc: 'Authentic Banarasi Katan silk saree woven with traditional floral jaal in antique gold zari. Comes with unstitched blouse piece.',
      images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'Free Size', colour: 'Crimson Red', stock: 9, price: 3499 },
      ]
    },
    {
      id: 'prd_07', cat: 'cat_sarees', name: 'Kanjivaram Style Soft Silk Saree with Temple Border', sku: 'KK-SAR-002',
      brand: 'South Silk Studio', regPrice: 5499, discPrice: 3999, colour: 'Royal Peacock Blue',
      sizes: ['Free Size'],
      desc: 'Heavy rich pallu Kanjivaram soft silk saree featuring contrasting magenta temple borders and rich peacock zari motifs.',
      images: ['https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'Free Size', colour: 'Royal Peacock Blue', stock: 6, price: 3999 },
        { size: 'Free Size', colour: 'Magenta Pink', stock: 5, price: 3999 },
      ]
    },
    {
      id: 'prd_08', cat: 'cat_sarees', name: 'Pure Handloom Chanderi Cotton Silk Saree', sku: 'KK-SAR-003',
      brand: 'KalaKriti Heritage', regPrice: 2899, discPrice: 2199, colour: 'Mint Green',
      sizes: ['Free Size'],
      desc: 'Lightweight translucent Chanderi drape with delicate gold coin buttas and sheer contrast border. Breathable and regal.',
      images: ['https://images.unsplash.com/photo-1609357605129-26f69add5d6e?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'Free Size', colour: 'Mint Green', stock: 8, price: 2199 },
        { size: 'Free Size', colour: 'Ivory Cream', stock: 7, price: 2199 },
      ]
    },
    {
      id: 'prd_09', cat: 'cat_sarees', name: 'Floral Embroidered Organza Saree with Scallop Work', sku: 'KK-SAR-004',
      brand: 'Vogue Drapes', regPrice: 3299, discPrice: 2499, colour: 'Lavender',
      sizes: ['Free Size'],
      desc: 'Modern sheer organza silk saree with all-over pastel thread embroidery and precision scalloped borders. Unmatched elegance.',
      images: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'Free Size', colour: 'Lavender', stock: 5, price: 2499 },
        { size: 'Free Size', colour: 'Powder Blue', stock: 4, price: 2499 },
      ]
    },
    {
      id: 'prd_10', cat: 'cat_sarees', name: 'Traditional Kalamkari Printed Cotton Saree', sku: 'KK-SAR-005',
      brand: 'Andhra Artisans', regPrice: 1999, discPrice: 1450, colour: 'Rust Ochre',
      sizes: ['Free Size'],
      desc: 'Authentic mythological narrative Kalamkari block prints crafted in natural earthy pigments on 100% pure Mulmul cotton.',
      images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'Free Size', colour: 'Rust Ochre', stock: 11, price: 1450 },
      ]
    },

    // Dresses & Gowns (11-14)
    {
      id: 'prd_11', cat: 'cat_dresses', name: 'Ethnic Tiered Anarkali Maxi Dress with Belt', sku: 'KK-DRS-001',
      brand: 'KalaKriti Modern', regPrice: 2699, discPrice: 1999, colour: 'Navy Blue',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Contemporary ethnic maxi gown with ruffled sleeves, sweetheart neckline, and embroidered waistband detailing.',
      images: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'S', colour: 'Navy Blue', stock: 6, price: 1999 },
        { size: 'M', colour: 'Navy Blue', stock: 10, price: 1999 },
        { size: 'L', colour: 'Navy Blue', stock: 7, price: 1999 },
        { size: 'XL', colour: 'Navy Blue', stock: 3, price: 1999 },
      ]
    },
    {
      id: 'prd_12', cat: 'cat_dresses', name: 'Boho Paisley Print Cotton Midi Sundress', sku: 'KK-DRS-002',
      brand: 'KalaKriti Modern', regPrice: 1699, discPrice: 1199, colour: 'Teal Green',
      sizes: ['XS', 'S', 'M', 'L'],
      desc: 'Relaxed tiered summer dress with adjustable spaghetti straps and breezy flared hemline.',
      images: ['https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'XS', colour: 'Teal Green', stock: 5, price: 1199 },
        { size: 'S', colour: 'Teal Green', stock: 8, price: 1199 },
        { size: 'M', colour: 'Teal Green', stock: 12, price: 1199 },
        { size: 'L', colour: 'Teal Green', stock: 9, price: 1199 },
      ]
    },
    {
      id: 'prd_13', cat: 'cat_dresses', name: 'Velvet Embroidered Partywear Festive Gown', sku: 'KK-DRS-003',
      brand: 'Royal Silhouette', regPrice: 4299, discPrice: 3199, colour: 'Wine Burgundy',
      sizes: ['M', 'L', 'XL'],
      desc: 'Plush Micro-velvet full length floor gown with antique sequin hand-work along neckline and bell cuffs.',
      images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'M', colour: 'Wine Burgundy', stock: 4, price: 3199 },
        { size: 'L', colour: 'Wine Burgundy', stock: 5, price: 3199 },
        { size: 'XL', colour: 'Wine Burgundy', stock: 3, price: 3199 },
      ]
    },
    {
      id: 'prd_14', cat: 'cat_dresses', name: 'Smocked Bodice Linen Wrap Fit Dress', sku: 'KK-DRS-004',
      brand: 'KalaKriti Modern', regPrice: 1999, discPrice: 1499, colour: 'Terracotta',
      sizes: ['S', 'M', 'L'],
      desc: 'Pure breathable linen blend wrap dress with flattering smocked back waist and side functional pockets.',
      images: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'S', colour: 'Terracotta', stock: 7, price: 1499 },
        { size: 'M', colour: 'Terracotta', stock: 11, price: 1499 },
        { size: 'L', colour: 'Terracotta', stock: 6, price: 1499 },
      ]
    },

    // Shirts (15-18)
    {
      id: 'prd_15', cat: 'cat_shirts', name: 'Pure Khadi Linen Mandarin Collar Shirt', sku: 'KK-SHT-001',
      brand: 'Gramin Threads', regPrice: 1899, discPrice: 1399, colour: 'Beige Off-White',
      sizes: ['38 (S)', '40 (M)', '42 (L)', '44 (XL)'],
      desc: '100% handspun organic linen shirt featuring neat stand collar, mother-of-pearl buttons, and moisture-wicking weave.',
      images: ['https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: '38 (S)', colour: 'Beige Off-White', stock: 10, price: 1399 },
        { size: '40 (M)', colour: 'Beige Off-White', stock: 15, price: 1399 },
        { size: '42 (L)', colour: 'Beige Off-White', stock: 12, price: 1399 },
        { size: '44 (XL)', colour: 'Beige Off-White', stock: 5, price: 1399 },
      ]
    },
    {
      id: 'prd_16', cat: 'cat_shirts', name: 'Sanganeri Hand Block Printed Cotton Casual Shirt', sku: 'KK-SHT-002',
      brand: 'Jaipur Loom', regPrice: 1499, discPrice: 1099, colour: 'Maroon Botanical',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Authentic Jaipur wooden block printed motif shirt with curved hem and spread collar for effortless summer styling.',
      images: ['https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80'],
      minStock: 5,
      variants: [
        { size: 'S', colour: 'Maroon Botanical', stock: 8, price: 1099 },
        { size: 'M', colour: 'Maroon Botanical', stock: 14, price: 1099 },
        { size: 'L', colour: 'Maroon Botanical', stock: 11, price: 1099 },
        { size: 'XL', colour: 'Maroon Botanical', stock: 6, price: 1099 },
      ]
    },
    {
      id: 'prd_17', cat: 'cat_shirts', name: 'Slim Fit Wrinkle-Free Formal Twill Shirt', sku: 'KK-SHT-003',
      brand: 'Executive Edge', regPrice: 1799, discPrice: 1249, colour: 'Sky Blue',
      sizes: ['39 (M)', '40 (M)', '42 (L)', '44 (XL)'],
      desc: 'High-density 100% Egyptian cotton twill weave shirt with non-iron finish and reinforced stiff collar.',
      images: ['https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: '39 (M)', colour: 'Sky Blue', stock: 10, price: 1249 },
        { size: '40 (M)', colour: 'Sky Blue', stock: 16, price: 1249 },
        { size: '42 (L)', colour: 'Sky Blue', stock: 13, price: 1249 },
        { size: '44 (XL)', colour: 'Sky Blue', stock: 7, price: 1249 },
      ]
    },
    {
      id: 'prd_18', cat: 'cat_shirts', name: 'Camp Collar Havana Striped Linen Casual Shirt', sku: 'KK-SHT-004',
      brand: 'Resort Club', regPrice: 1599, discPrice: 1150, colour: 'Sage Olive Stripe',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Cuban camp collar short sleeve shirt featuring vertical yarn-dyed earthy stripes. Relaxed holiday fit.',
      images: ['https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'S', colour: 'Sage Olive Stripe', stock: 6, price: 1150 },
        { size: 'M', colour: 'Sage Olive Stripe', stock: 10, price: 1150 },
        { size: 'L', colour: 'Sage Olive Stripe', stock: 8, price: 1150 },
        { size: 'XL', colour: 'Sage Olive Stripe', stock: 4, price: 1150 },
      ]
    },

    // T-shirts (19-21)
    {
      id: 'prd_19', cat: 'cat_tshirts', name: 'Heavyweight 240 GSM Oversized Graphic Tee', sku: 'KK-TEE-001',
      brand: 'StreetCulture', regPrice: 999, discPrice: 699, colour: 'Charcoal Black',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Thick combed cotton drop-shoulder boxy fit tee with screen-printed geometric typographic art on back.',
      images: ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80'],
      minStock: 6,
      variants: [
        { size: 'S', colour: 'Charcoal Black', stock: 15, price: 699 },
        { size: 'M', colour: 'Charcoal Black', stock: 25, price: 699 },
        { size: 'L', colour: 'Charcoal Black', stock: 20, price: 699 },
        { size: 'XL', colour: 'Charcoal Black', stock: 12, price: 699 },
      ]
    },
    {
      id: 'prd_20', cat: 'cat_tshirts', name: 'Supima Cotton Classic Crew Neck T-Shirt', sku: 'KK-TEE-002',
      brand: 'PureBasics', regPrice: 899, discPrice: 599, colour: 'White',
      sizes: ['S', 'M', 'L', 'XL'],
      desc: 'Silky smooth extra-long staple Supima cotton essential tee with ribbed collar and zero shrinkage wash.',
      images: ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=80'],
      minStock: 8,
      variants: [
        { size: 'S', colour: 'White', stock: 20, price: 599 },
        { size: 'M', colour: 'White', stock: 30, price: 599 },
        { size: 'L', colour: 'White', stock: 25, price: 599 },
        { size: 'XL', colour: 'White', stock: 15, price: 599 },
      ]
    },
    {
      id: 'prd_21', cat: 'cat_tshirts', name: 'Textured Waffle Knit Raglan Henley T-Shirt', sku: 'KK-TEE-003',
      brand: 'UrbanHeritage', regPrice: 1199, discPrice: 849, colour: 'Forest Green',
      sizes: ['M', 'L', 'XL'],
      desc: 'Honeycomb thermal waffle texture shirt with three metal button placket and ribbed cuffs.',
      images: ['https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'M', colour: 'Forest Green', stock: 11, price: 849 },
        { size: 'L', colour: 'Forest Green', stock: 14, price: 849 },
        { size: 'XL', colour: 'Forest Green', stock: 7, price: 849 },
      ]
    },

    // Jeans & Bottoms (22-24)
    {
      id: 'prd_22', cat: 'cat_jeans', name: 'Vintage Washed High Rise Wide Leg Jeans', sku: 'KK-JNS-001',
      brand: 'DenimCraft', regPrice: 2499, discPrice: 1799, colour: 'Light Indigo',
      sizes: ['28', '30', '32', '34'],
      desc: 'Authentic 100% rigid cotton denim trousers with vintage whisker wash, high rise silhouette and relaxed hem.',
      images: ['https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: '28', colour: 'Light Indigo', stock: 7, price: 1799 },
        { size: '30', colour: 'Light Indigo', stock: 12, price: 1799 },
        { size: '32', colour: 'Light Indigo', stock: 10, price: 1799 },
        { size: '34', colour: 'Light Indigo', stock: 5, price: 1799 },
      ]
    },
    {
      id: 'prd_23', cat: 'cat_jeans', name: 'Flex Comfort Slim Tapered Stretch Chino Jeans', sku: 'KK-JNS-002',
      brand: 'UrbanVibe', regPrice: 2199, discPrice: 1599, colour: 'Dark Charcoal Grey',
      sizes: ['30', '32', '34', '36'],
      desc: 'Performance stretch cotton with 4-way flexibility, tailored slim taper, and anti-fade reactive dye.',
      images: ['https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: '30', colour: 'Dark Charcoal Grey', stock: 9, price: 1599 },
        { size: '32', colour: 'Dark Charcoal Grey', stock: 15, price: 1599 },
        { size: '34', colour: 'Dark Charcoal Grey', stock: 11, price: 1599 },
        { size: '36', colour: 'Dark Charcoal Grey', stock: 6, price: 1599 },
      ]
    },
    {
      id: 'prd_24', cat: 'cat_jeans', name: 'Ethnic Chanderi Wide Leg Palazzo Pants', sku: 'KK-JNS-003',
      brand: 'KalaKriti Heritage', regPrice: 1499, discPrice: 999, colour: 'Golden Beige',
      sizes: ['Free Size (Elasticated)'],
      desc: 'Lined flared palazzo with gold Zari border at hem, deep dual pockets and comfortable elasticated drawcord waist.',
      images: ['https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'Free Size', colour: 'Golden Beige', stock: 16, price: 999 },
        { size: 'Free Size', colour: 'Black', stock: 12, price: 999 },
      ]
    },

    // Footwear (25-27)
    {
      id: 'prd_25', cat: 'cat_footwear', name: 'Handcrafted Punjabi Leather Jutti with Dabka Work', sku: 'KK-FTW-001',
      brand: 'Amritsar Jutti Co.', regPrice: 1899, discPrice: 1399, colour: 'Gold & Ivory',
      sizes: ['Euro 37', 'Euro 38', 'Euro 39', 'Euro 40'],
      desc: 'Genuine vegetable tanned leather juttis cushioned with memory foam sole and ornate Zardozi thread embroidery.',
      images: ['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'Euro 37', colour: 'Gold & Ivory', stock: 4, price: 1399 },
        { size: 'Euro 38', colour: 'Gold & Ivory', stock: 6, price: 1399 },
        { size: 'Euro 39', colour: 'Gold & Ivory', stock: 5, price: 1399 },
        { size: 'Euro 40', colour: 'Gold & Ivory', stock: 3, price: 1399 },
      ]
    },
    {
      id: 'prd_26', cat: 'cat_footwear', name: 'Kolhapuri Braided T-Strap Leather Slip-ons', sku: 'KK-FTW-002',
      brand: 'Deccan Crafts', regPrice: 1499, discPrice: 1099, colour: 'Tan Brown',
      sizes: ['Euro 38', 'Euro 39', 'Euro 40', 'Euro 41'],
      desc: 'Authentic Kolhapuri braided toe-ring slippers handcrafted with treated buffalo hide and decorative pompom accents.',
      images: ['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'Euro 38', colour: 'Tan Brown', stock: 5, price: 1099 },
        { size: 'Euro 39', colour: 'Tan Brown', stock: 7, price: 1099 },
        { size: 'Euro 40', colour: 'Tan Brown', stock: 6, price: 1099 },
        { size: 'Euro 41', colour: 'Tan Brown', stock: 4, price: 1099 },
      ]
    },
    {
      id: 'prd_27', cat: 'cat_footwear', name: 'Cushioned Block Heel Ethnic Embroidered Mules', sku: 'KK-FTW-003',
      brand: 'VelvetSteps', regPrice: 2299, discPrice: 1699, colour: 'Emerald Green',
      sizes: ['Euro 37', 'Euro 38', 'Euro 39'],
      desc: '2.5 inch sturdy block heel mules wrapped in raw silk with mirrorwork embroidery and anti-slip rubber outsole.',
      images: ['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: 'Euro 37', colour: 'Emerald Green', stock: 3, price: 1699 },
        { size: 'Euro 38', colour: 'Emerald Green', stock: 5, price: 1699 },
        { size: 'Euro 39', colour: 'Emerald Green', stock: 4, price: 1699 },
      ]
    },

    // Jewellery & Accessories (28-32)
    {
      id: 'prd_28', cat: 'cat_jewellery', name: 'Royal 22K Gold Plated Kundan Choker Necklace Set', sku: 'KK-JWL-001',
      brand: 'Rajputana Jewels', regPrice: 2999, discPrice: 2199, colour: 'Antique Gold & Pearl',
      sizes: ['Adjustable Dori'],
      desc: 'Traditional Jadau Kundan bridal choker necklace paired with matching hanging Jhumka earrings and Maang Tikka.',
      images: ['https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'Adjustable Dori', colour: 'Antique Gold & Pearl', stock: 8, price: 2199 },
        { size: 'Adjustable Dori', colour: 'Ruby Emerald Accent', stock: 6, price: 2199 },
      ]
    },
    {
      id: 'prd_29', cat: 'cat_jewellery', name: 'Oxidised Silver Boho Chandbali Jhumka Earrings', sku: 'KK-JWL-002',
      brand: 'TribalSilver', regPrice: 899, discPrice: 499, colour: 'Oxidised Silver',
      sizes: ['One Size (7cm length)'],
      desc: 'Classic vintage dome ghungroo drop Chandbali earrings crafted in skin-friendly brass with German silver polish.',
      images: ['https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=600&auto=format&fit=crop&q=80'],
      minStock: 5,
      variants: [
        { size: 'One Size', colour: 'Oxidised Silver', stock: 24, price: 499 },
      ]
    },
    {
      id: 'prd_30', cat: 'cat_jewellery', name: 'Raw Silk Embroidered Potli Bag with Pearl Handle', sku: 'KK-ACC-001',
      brand: 'KalaKriti Heritage', regPrice: 1199, discPrice: 799, colour: 'Maroon & Gold',
      sizes: ['Medium (20cm x 18cm)'],
      desc: 'Exquisite festive drawstring pouch bag adorned with Zardozi floral embroidery and heavy beaded pearl wristlet handle.',
      images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&auto=format&fit=crop&q=80'],
      minStock: 4,
      variants: [
        { size: 'Medium', colour: 'Maroon & Gold', stock: 14, price: 799 },
        { size: 'Medium', colour: 'Gold & Ivory', stock: 12, price: 799 },
      ]
    },
    {
      id: 'prd_31', cat: 'cat_jewellery', name: 'Meenakari Hand-painted Temple Kada Bangles (Set of 2)', sku: 'KK-JWL-003',
      brand: 'Jaipur Crafts', regPrice: 1599, discPrice: 1150, colour: 'Peacock Enamel',
      sizes: ['2.4', '2.6', '2.8'],
      desc: 'Screw openable antique brass kada bangles with hand-painted peacock meenakari art and synthetic ruby stone embellishment.',
      images: ['https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'],
      minStock: 2,
      variants: [
        { size: '2.4', colour: 'Peacock Enamel', stock: 4, price: 1150 },
        { size: '2.6', colour: 'Peacock Enamel', stock: 6, price: 1150 },
        { size: '2.8', colour: 'Peacock Enamel', stock: 3, price: 1150 },
      ]
    },
    {
      id: 'prd_32', cat: 'cat_jewellery', name: 'Heavy Zircon Crystal Tennis Bracelet', sku: 'KK-JWL-004',
      brand: 'LuxeGleam', regPrice: 1899, discPrice: 1299, colour: 'Rose Gold',
      sizes: ['Standard 7 inch (Stretch/Clasp)'],
      desc: 'Sparkling AAA Austrian Cubic Zirconia stones set in hypoallergenic rose gold rhodium plating with double security lock.',
      images: ['https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=600&auto=format&fit=crop&q=80'],
      minStock: 3,
      variants: [
        { size: 'Standard 7 inch', colour: 'Rose Gold', stock: 7, price: 1299 },
        { size: 'Standard 7 inch', colour: 'Silver Platinum', stock: 5, price: 1299 },
      ]
    }
  ];

  const insertProduct = db.prepare(`
    INSERT INTO products (
      id, business_id, category_id, name, sku, description, brand,
      regular_price, discount_price, colour, sizes, images, is_archived, min_stock_threshold
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
  `);

  const insertVariant = db.prepare(`
    INSERT INTO product_variants (
      id, product_id, business_id, sku, size, colour, price, discount_price, stock_quantity
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertMovement = db.prepare(`
    INSERT INTO inventory_movements (
      id, business_id, product_id, variant_id, change_qty, balance_after, movement_type, notes
    ) VALUES (?, ?, ?, ?, ?, ?, 'PURCHASE', 'Initial stock intake')
  `);

  for (const p of productsData) {
    insertProduct.run(
      p.id,
      biz1Id,
      p.cat,
      p.name,
      p.sku,
      p.desc,
      p.brand,
      p.regPrice,
      p.discPrice,
      p.colour,
      JSON.stringify(p.sizes),
      JSON.stringify(p.images),
      p.minStock
    );

    p.variants.forEach((v, idx) => {
      const varId = `var_${p.id}_${idx + 1}`;
      const varSku = `${p.sku}-${v.size.replace(/\s+/g, '')}-${v.colour.substring(0, 3).toUpperCase()}`;
      insertVariant.run(
        varId,
        p.id,
        biz1Id,
        varSku,
        v.size,
        v.colour,
        p.regPrice,
        v.price,
        v.stock
      );

      // Ledger movement
      insertMovement.run(
        `mov_${varId}_init`,
        biz1Id,
        p.id,
        varId,
        v.stock,
        v.stock
      );
    });
  }

  // Add 1 sample product for Biz 2 (UrbanVogue) to demonstrate data isolation
  insertProduct.run(
    'prd_uv_01',
    biz2Id,
    'cat_uv_street',
    'Urban Raw Edge Distressed Denim Jacket',
    'UV-JKT-001',
    'Heavy 14oz Japanese cotton denim jacket with distressed wash and matte brass buttons.',
    'UrbanVogue Studio',
    3499,
    2799,
    'Faded Indigo',
    JSON.stringify(['M', 'L', 'XL']),
    JSON.stringify(['https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&auto=format&fit=crop&q=80']),
    3
  );

  insertVariant.run(
    'var_uv_01_1',
    'prd_uv_01',
    biz2Id,
    'UV-JKT-001-M-IND',
    'M',
    'Faded Indigo',
    3499,
    2799,
    15
  );

  // 5. Seed Customers for KalaKriti
  const insertCust = db.prepare(`
    INSERT INTO customers (id, business_id, user_id, name, phone, email, address, city, state, postal_code)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insertCust.run(
    'cust_ananya_01',
    biz1Id,
    'usr_cust_1',
    'Ananya Sen',
    '+91 98765 11111',
    'ananya@example.com',
    'Flat 402, Green Acres Apt, Indiranagar',
    'Bengaluru',
    'Karnataka',
    '560038'
  );

  insertCust.run(
    'cust_rohit_02',
    biz1Id,
    null,
    'Rohit Verma',
    '+91 98765 22222',
    'rohit.v@example.com',
    'House 12, Sector 14, HSR Layout',
    'Bengaluru',
    'Karnataka',
    '560102'
  );

  insertCust.run(
    'cust_meera_03',
    biz1Id,
    null,
    'Meera Krishnan',
    '+91 98765 33333',
    'meera.k@example.com',
    'Plot 88, Anna Nagar West',
    'Chennai',
    'Tamil Nadu',
    '600040'
  );

  // 6. Seed Sample Orders with transaction snapshots
  const insertOrder = db.prepare(`
    INSERT INTO orders (
      id, business_id, customer_id, order_number, order_date,
      subtotal, discount, tax, total_amount, delivery_address,
      payment_method, payment_status, order_status, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertOrderItem = db.prepare(`
    INSERT INTO order_items (
      id, order_id, product_id, variant_id, product_name, variant_details, quantity, unit_price, total_price
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  // Order 1 (Delivered)
  insertOrder.run(
    'ord_001',
    biz1Id,
    'cust_ananya_01',
    'ORD-2026-1001',
    '2026-11-04 14:30:00',
    2798,
    200,
    0,
    2598,
    'Flat 402, Green Acres Apt, Indiranagar, Bengaluru, Karnataka, 560038',
    'UPI / Online',
    'Paid',
    'Delivered',
    'Left with security as requested'
  );
  insertOrderItem.run(
    'item_001_1',
    'ord_001',
    'prd_01',
    'var_prd_01_2',
    'Ananya Pure Cotton Kurti with Dupatta',
    'Size: M | Colour: Red',
    2,
    1399,
    2798
  );

  // Order 2 (Processing)
  insertOrder.run(
    'ord_002',
    biz1Id,
    'cust_rohit_02',
    'ORD-2026-1002',
    '2026-11-05 11:15:00',
    2498,
    0,
    0,
    2498,
    'House 12, Sector 14, HSR Layout, Bengaluru, Karnataka, 560102',
    'Cash on Delivery',
    'Pending',
    'Processing',
    'Please call before dispatch'
  );
  insertOrderItem.run(
    'item_002_1',
    'ord_002',
    'prd_15',
    'var_prd_15_2',
    'Pure Khadi Linen Mandarin Collar Shirt',
    'Size: 40 (M) | Colour: Beige Off-White',
    1,
    1399,
    1399
  );
  insertOrderItem.run(
    'item_002_2',
    'ord_002',
    'prd_16',
    'var_prd_16_2',
    'Sanganeri Hand Block Printed Cotton Casual Shirt',
    'Size: M | Colour: Maroon Botanical',
    1,
    1099,
    1099
  );

  // Order 3 (Confirmed / Pending Dispatch)
  insertOrder.run(
    'ord_003',
    biz1Id,
    'cust_meera_03',
    'ORD-2026-1003',
    '2026-11-06 08:45:00',
    3499,
    0,
    0,
    3499,
    'Plot 88, Anna Nagar West, Chennai, Tamil Nadu, 600040',
    'UPI / Online',
    'Paid',
    'Confirmed',
    'Gift wrap requested with note'
  );
  insertOrderItem.run(
    'item_003_1',
    'ord_003',
    'prd_06',
    'var_prd_06_1',
    'Banarasi Katan Silk Woven Saree in Crimson Red',
    'Size: Free Size | Colour: Crimson Red',
    1,
    3499,
    3499
  );

  // 7. Seed Sample Conversations & Messages
  const insertConv = db.prepare(`
    INSERT INTO conversations (
      id, business_id, customer_id, customer_name, customer_phone, status, channel, assigned_employee_id, ai_summary
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertMsg = db.prepare(`
    INSERT INTO messages (id, conversation_id, sender_type, sender_name, content, metadata, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  insertConv.run(
    'conv_001',
    biz1Id,
    'cust_ananya_01',
    'Ananya Sen',
    '+91 98765 11111',
    'Resolved',
    'WHATSAPP_SIMULATOR',
    'usr_emp_1',
    'Customer was looking for festive red kurtis under ₹1,500 for family gathering. Picked Anarkali Cotton Kurti in Size M, completed order ORD-2026-1001.'
  );

  insertMsg.run(
    'msg_01',
    'conv_001',
    'CUSTOMER',
    'Ananya Sen',
    'Hi! Show me red kurtis below ₹1,500.',
    null,
    '2026-11-04 14:15:00'
  );

  insertMsg.run(
    'msg_02',
    'conv_001',
    'AI',
    'ShopMate AI',
    'Namaste Ananya! I found 2 wonderful red ethnic kurtis matching your criteria: Anarkali Pure Cotton Kurti with Dupatta at ₹1,399 (Original ₹1,899). What size would you like to check?',
    JSON.stringify({ suggestedProducts: ['prd_01'] }),
    '2026-11-04 14:15:05'
  );

  insertMsg.run(
    'msg_03',
    'conv_001',
    'CUSTOMER',
    'Ananya Sen',
    'Do you have size M available?',
    null,
    '2026-11-04 14:16:00'
  );

  insertMsg.run(
    'msg_04',
    'conv_001',
    'AI',
    'ShopMate AI',
    'Yes, size M is in stock! We currently have 18 pieces ready for immediate dispatch at ₹1,399 each. Would you like to add it to your order?',
    JSON.stringify({ variantAvailable: true, stock: 18 }),
    '2026-11-04 14:16:04'
  );

  // 8. Integrations
  const insertInt = db.prepare(`
    INSERT INTO integrations (id, business_id, provider, status, phone_number, webhook_url, settings_json)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  insertInt.run(
    'int_whatsapp_01',
    biz1Id,
    'WhatsApp Cloud API',
    'Connected',
    '+91 98765 43210',
    'https://ais-dev-nfglvtxfpnwjaimhgelv6b-396491336642.asia-east1.run.app/webhooks/whatsapp',
    JSON.stringify({
      verified: true,
      autoReply: true,
      businessAccountId: 'WABA_894102941',
      displayPhoneNumber: '+91 98765 43210',
      simulatorActive: true
    })
  );

  console.log('Seeding completed successfully! 32 products, variants, ledger movements, sample orders and conversations initialized.');
}
